//  ROLL ENGINE v7.6 — PORT EKSAK The Dice 1.4 ASLI (net.dzyga)
//
//  AUDIT 10 Okt 2026 vs dex asli membuktikan v7.4 masih menyimpang di
//  tiga titik mekanik. v7.5 membekukan semuanya ke perilaku asli:
//
//  1. TEMPO 200ms (asli: Tick200mils + anim 200ms; v7.4 sempat 225ms).
//  2. FRAME PEMBUKA: asli HARD-CUT wajah lama diganti wajah 6 TANPA
//     animasi keluar, lalu DALAM INSTAN YANG SAMA animasi 6->1 berjalan
//     (setImageResource(DICE_IMG[5]) + hideLeft/showRight serentak).
//     Satu gerakan 200ms menuju wajah 1. v7.4 dulu transisi old->6
//     lalu diam -> butuh 450ms. Wajah 6 kini hanya tampak sebagai
//     lapisan yang menyusut, persis asli.
//  3. URUTAN WAJAH PER TICK: tick k menampilkan transisi wajah k -> k+1
//     (asli: dice = DICE_IMG[secCounter], diceA = DICE_IMG[secCounter+1];
//     secCounter = k-1 => masuk wajah k+1 = secCounter+2). v7.4 tertinggal
//     satu wajah.
//  4. MOMEN BERHENTI: dadu berhenti PADA tick ketika secCounter ==
//     randArr (asli: countdownFinished && secCounter == randArr ->
//     clearAnimation, wajah hasil SUDAH tiba penuh dari tick sebelumnya).
//     Tidak ada transisi tambahan saat mendarat. v7.4 memulai satu
//     transisi ekstra. Tanpa animasi baru saat stop = tanpa snap.
//  5. TAP SAAT BERPUTAR = RESTART PENUH (asli: onClick mengundi ulang,
//     stopped[] reset, konter 5, hitung mundur 3s baru). v7.4 mengabaikan
//     tap dan membuang satu ronde komposisi.
//  6. ATURAN SENTUH v7.2 (jari menempel = dadu tak mendarat) kini hanya
//     aktif di mode "kk". Mode default = perilaku asli murni: dadu
//     mendarat setelah 3 detik apa pun yang disentuh.
//
//  Komposisi 100 ronde (87/5/8) tetap: hasil DITETAPKAN SEBELUM animasi
//  (arsitektur asli: randArr diundi saat tap, animasi hanya menerima).
//
//   Perilaku default = tak bisa dibedakan dari APK asli.
//  v7.6: hasil murni acak per dadu, jumlah dadu ikut menu 1/2/3.

var FRAME_MS = 200;      // asli: Tick200mils, postDelayed 200L
var MIN_SPIN_MS = 3000;   // asli: diceLayout.postDelayed 3000L
var TOUCH_CALM_MS = 400;  // hanya mode "kk" (fitur operator, bukan asli)

// Konter global wajah (0..5 = wajah 1..6), asli: secCounter
var secCounter = 0;
var minSpinDone = false;  // asli: countdownFinished
var tickTimer = null;     // asli: removeCallbacks/postDelayed di dice[0]
var spinTimer = null;
var balls = [];
var rolling = false;
// v7.7: jendela pendaratan terurut 2 -> 3 -> 4 -> 5 -> 6 -> 1
var stopWindowOpen = false;

// Wajah masuk pada konter sekarang (asli: DICE_IMG[secCounter+1])
function wrapFace(n) {
    return n > 6 ? n - 6 : n;
}

// FRAME PEMBUKA ASLI — dipanggil saat lemparan dimulai/restart:
//  - seluruh isi dadu diganti SEKETIKA (asli: setImageResource,
//    wajah hasil lemparan sebelumnya hilang tanpa animasi keluar)
//  - lapisan .left = wajah 6 (akan menyusut keluar kiri)
//  - lapisan .right = wajah 1 (tumbuh dari tepi kanan)
//  - keduanya berjalan serentak dalam satu gerakan FRAME_MS
function openingFace(ball) {
    var $element = $(ball.element);
    var EASE = "cubic-bezier(0.42, 0, 0.58, 1)";
    $element.empty();
    $element.append('<img class="left" src="Img/6.svg"><img class="right" src="Img/1.svg">');
    var $l = $element.find(".left");
    var $r = $element.find(".right");
    $l.css({ "transform-origin": "0% 50%", "transform": "scale(1, 1)", "transition": "none" });
    $r.css({ "transform-origin": "100% 50%", "transform": "scale(0, 0.8)", "transition": "none" });
    $l.get(0).offsetWidth; // paksa reflow sebelum transisi dipasang
    $l.css({ "transition": "transform " + FRAME_MS + "ms " + EASE, "transform": "scale(0, 0.8)" });
    $r.css({ "transition": "transform " + FRAME_MS + "ms " + EASE, "transform": "scale(1, 1)" });
}

function initRoll(diceEls) {
    rolling = true;
    secCounter = 5;        // asli: secCounter = 5 saat dadu dilempar
    minSpinDone = false;   // asli: countdownFinished = false
    stopWindowOpen = false; // v7.7: reset jendela pendaratan
    balls = [];
    for (var i = 0; i < diceEls.length; i++) {
        balls.push({ element: diceEls[i], value: results[i], stoped: false });
    }
    // Asli: onClick mengulang pengaturan pembuka untuk SEMUA dadu —
    // dipanggil juga saat lemparan direstart di tengah putaran.
    balls.forEach(openingFace);
    // Asli: dice[0].removeCallbacks(tick) + postDelayed(tick, 200L)
    if (tickTimer) clearTimeout(tickTimer);
    tickTimer = setTimeout(tick, FRAME_MS);
    // Asli: diceLayout.postDelayed(countdownFinished=true, 3000L)
    if (spinTimer) clearTimeout(spinTimer);
    spinTimer = setTimeout(function() { minSpinDone = true; }, MIN_SPIN_MS);
}

// Satu langkah putaran global (asli: Tick200mils.run)
function tick() {
    // Majukan konter global, kembali ke 0 setelah 5 (asli)
    secCounter += 1;
    if (secCounter >= 6) {
        secCounter = 0;
    }

    // Mode kk: dadu tak mendarat selama layar disentuh (v7.2, fitur
    // operator). Mode default: boleh berhenti murni dari hitung mundur,
    // persis asli.
    var bolehBerhenti = minSpinDone && stopWindowOpen; // v7.7: terurut
    if (typeof mode !== "undefined" && mode == "kk") {
        bolehBerhenti = bolehBerhenti &&
            !isTouchDown &&
            (Date.now() - lastTouchAt) >= TOUCH_CALM_MS;
    }

    // v7.7: jendela pendaratan dibuka saat konter tepat di posisi 1
    // (wajah 2). Sejak titik itu dadu berhenti mengikuti urutan nilai
    // 2 -> 3 -> 4 -> 5 -> 6 -> 1; nilai kembar berhenti serentak
    // karena berbagi posisi konter yang sama.
    if (minSpinDone && !stopWindowOpen && secCounter == 1) {
        stopWindowOpen = true;
    }

    // Wajah yang masuk pada tick ini (asli: DICE_IMG[secCounter+1])
    var face = wrapFace(secCounter + 2);
    var anySpinning = false;

    balls.forEach(function(ball) {
        if (ball.stoped) {
            return;
        }
        // Asli: if (countdownFinished && secCounter == randArr[i])
        //   -> stopped[i] = true, clearAnimation, TANPA wajah baru.
        // Wajah hasil sudah tiba penuh dari tick sebelumnya.
        if (bolehBerhenti && secCounter == ball.value - 1) {
            ball.stoped = true;
            return;
        }
        showFace(ball, face);
        anySpinning = true;
    });

    if (anySpinning) {
        tickTimer = setTimeout(tick, FRAME_MS); // asli: postDelayed(tick, 200L)
    } else {
        onAllStoped(); // asli: tick berhenti dipost ulang begitu semua diam
    }
}

function onAllStoped() {
    rolling = false;
    prevRes = results;
    preRes = [];
    round += 1;
    isRemoted = false;
}

// Tampilkan satu wajah pada satu dadu (port show_right.xml + hide_left.xml)
function showFace(ball, face) {
    var $element = $(ball.element);
    var EASE = "cubic-bezier(0.42, 0, 0.58, 1)"; // ~= AccelerateDecelerate

    // Wajah sebelumnya dipromosikan jadi wajah lama
    $element.find(".right").removeClass("right").addClass("left");

    // Wajah baru dipasang dalam keadaan sliver di tepi kanan
    // (asli: fromXScale=0, fromYScale=0.8, pivotX=100%)
    $element.append('<img class="right" src="Img/' + face + '.svg">');
    var $newFace = $element.find(".right");
    $newFace.css({
        "transform-origin": "100% 50%",
        "transform": "scale(0, 0.8)",
        "transition": "none"
    });

    // Paksa satu reflow, lalu transisi ke ukuran penuh
    $newFace.get(0).offsetWidth;
    $newFace.css({
        "transition": "transform " + FRAME_MS + "ms " + EASE,
        "transform": "scale(1, 1)"
    });

    // Wajah lama menyusut jadi sliver di tepi kiri lalu dibuang
    // (asli: toXScale=0, toYScale=0.8, pivotX=0%, fillAfter=false)
    $element.find(".left").each(function() {
        var old = this;
        old.style["transform-origin"] = "0% 50%";
        old.style.transition = "transform " + FRAME_MS + "ms " + EASE;
        old.style.transform = "scale(0, 0.8)";
        setTimeout(function() {
            $(old).remove();
        }, FRAME_MS);
    });
}
