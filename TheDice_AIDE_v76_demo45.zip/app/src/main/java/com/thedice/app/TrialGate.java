package com.thedice.app;

/** Gerbang masa uji 45 menit. Logika murni agar bisa diuji di JVM. */
public class TrialGate {
    public static final long LIMIT_MS = 45L * 60 * 1000; // 45 menit
    private long usedMs;
    private boolean activated;

    public TrialGate(long usedMs, boolean activated) {
        this.usedMs = usedMs;
        this.activated = activated;
    }

    /** Tambah waktu pemakaian (delta monotonic). Delta gila (>10 detik per tick) diabaikan. */
    public long addDelta(long delta) {
        if (delta > 0 && delta <= 10000) usedMs += delta;
        return usedMs;
    }

    public boolean isExpired() { return !activated && usedMs >= LIMIT_MS; }

    public long remainingMs() { return Math.max(0, LIMIT_MS - usedMs); }

    public long getUsedMs() { return usedMs; }

    public void activate() { this.activated = true; }
}
