package com.thedice.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Window;
import android.view.WindowManager;
import android.view.View;
import android.view.Gravity;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.content.SharedPreferences;
import android.widget.Toast;
import android.app.AlertDialog;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;

public class MainActivity extends Activity {
    private WebView webView;
    private SharedPreferences prefs;
    private boolean backEnabled = false;

    // === TIMEBOMB / TRIAL 45 MENIT ===
    private static final String KODE_AKTIVASI = "DARMAWAN2026";
    private TrialGate gate;
    private java.util.Timer trialTimer;
    private long rtStart;
    private boolean locked = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        prefs = getSharedPreferences("TheDice", MODE_PRIVATE);

        gate = new TrialGate(prefs.getLong("trialUsedMs", 0), prefs.getBoolean("trialActivated", false));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.setLayerType(WebView.LAYER_TYPE_HARDWARE, null);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setUseWideViewPort(false);
        s.setLoadWithOverviewMode(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new DroidScriptBridge(), "app");

        if (gate.isExpired()) {
            showLock();
        } else {
            setContentView(webView);
            webView.loadUrl("file:///android_asset/The Dice.html");
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (!gate.isExpired()) {
            rtStart = SystemClock.elapsedRealtime();
            startTrialTimer();
        }
    }

    @Override protected void onPause() {
        super.onPause();
        stopTrialTimer();
        saveTrial();
    }

    private void startTrialTimer() {
        stopTrialTimer();
        trialTimer = new java.util.Timer();
        trialTimer.scheduleAtFixedRate(new java.util.TimerTask() {
            @Override public void run() {
                long now = SystemClock.elapsedRealtime();
                final long delta = now - rtStart;
                rtStart = now;
                runOnUiThread(() -> {
                    gate.addDelta(delta);
                    saveTrial();
                    if (gate.isExpired()) {
                        stopTrialTimer();
                        showLock();
                    }
                });
            }
        }, 1000, 1000);
    }

    private void stopTrialTimer() {
        if (trialTimer != null) { trialTimer.cancel(); trialTimer = null; }
    }

    private void saveTrial() {
        prefs.edit().putLong("trialUsedMs", gate.getUsedMs()).putBoolean("trialActivated",
            gate.isExpired() ? prefs.getBoolean("trialActivated", false) : prefs.getBoolean("trialActivated", false)).apply();
        // catatan: flag aktivasi disimpan lewat method activateApp()
    }

    private void activateApp() {
        gate.activate();
        prefs.edit().putBoolean("trialActivated", true).apply();
        locked = false;
        Toast.makeText(this, "Aktivasi berhasil. Terima kasih!", Toast.LENGTH_LONG).show();
        recreate();
    }

    private void showLock() {
        locked = true;
        stopTrialTimer();

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(Color.rgb(20, 20, 20));
        box.setGravity(Gravity.CENTER);
        box.setPadding(60, 60, 60, 60);

        TextView title = new TextView(this);
        title.setText("Masa Uji Berakhir");
        title.setTextSize(22);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setTextColor(Color.rgb(255, 216, 61));
        title.setGravity(Gravity.CENTER);

        TextView body = new TextView(this);
        body.setText("Masa uji 45 menit aplikasi ini telah habis.\n\nSilakan hubungi pembuat aplikasi untuk melakukan aktivasi dan pembayaran.");
        body.setTextSize(15);
        body.setTextColor(Color.WHITE);
        body.setGravity(Gravity.CENTER);
        body.setPadding(0, 40, 0, 40);

        final EditText code = new EditText(this);
        code.setHint("Kode aktivasi");
        code.setTextColor(Color.WHITE);
        code.setHintTextColor(Color.GRAY);

        Button btn = new Button(this);
        btn.setText("Aktivasi");
        btn.setOnClickListener(v -> {
            if (KODE_AKTIVASI.equals(code.getText().toString().trim())) {
                activateApp();
            } else {
                Toast.makeText(this, "Kode aktivasi salah.", Toast.LENGTH_SHORT).show();
            }
        });

        box.addView(title);
        box.addView(body);
        box.addView(code);
        box.addView(btn);
        setContentView(box);
    }

    @Override public void onBackPressed() {
        if (locked) { moveTaskToBack(true); return; }
        // BUG FIX: tombol back dulu tidak berfungsi sama sekali karena
        // EnableBackKey(false) membuat method ini tidak melakukan apa pun.
        // Konvensi DroidScript: EnableBackKey(false) = tombol back ditangani
        // JavaScript lewat fungsi global OnBack.
        // Di dalam game  : OnBack = hideGame -> balik ke menu awal.
        // Di menu awal   : OnBack = exit     -> keluar aplikasi.
        if (backEnabled) { super.onBackPressed(); return; }
        webView.evaluateJavascript(
            "typeof OnBack === 'function' ? OnBack() : app.Exit()", null);
    }

    private class DroidScriptBridge {
        @JavascriptInterface public void SetScreenMode(String mode) {}
        @JavascriptInterface public void EnableBackKey(boolean enabled) { backEnabled = enabled; }
        @JavascriptInterface public void SetDebugEnabled(boolean enabled) {}
        @JavascriptInterface public void SetOrientation(String orientation) {}
        @JavascriptInterface public void SetOptions(String key, boolean value) {}
        @JavascriptInterface public void SetBackColor(String color) {}
        @JavascriptInterface public String GetAppPath() { return "/android_asset/The Dice"; }
        @JavascriptInterface public void CopyFile(String src, String dst) {}
        @JavascriptInterface public void Exit() { runOnUiThread(() -> finish()); }
        @JavascriptInterface public void PreventScreenLock(boolean yes) {
            runOnUiThread(() -> {
                if (yes) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }
        @JavascriptInterface public void SaveBoolean(String key, boolean value) { prefs.edit().putBoolean(key, value).apply(); }
        @JavascriptInterface public boolean LoadBoolean(String key, boolean def) { return prefs.getBoolean(key, def); }
        @JavascriptInterface public void SaveText(String key, String value) { prefs.edit().putString(key, value).apply(); }
        @JavascriptInterface public String LoadText(String key, String def) { return prefs.getString(key, def); }
        @JavascriptInterface public void SaveNumber(String key, double value) { prefs.edit().putLong(key, Double.doubleToRawLongBits(value)).apply(); }
        @JavascriptInterface public double LoadNumber(String key, double def) {
            long x = prefs.getLong(key, Double.doubleToRawLongBits(def));
            return Double.longBitsToDouble(x);
        }
        @JavascriptInterface public void ShowPopup(final String text) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, text, Toast.LENGTH_SHORT).show());
        }
        @JavascriptInterface public void ShowYesNo(final String title) {
            runOnUiThread(() -> new AlertDialog.Builder(MainActivity.this)
                .setMessage(title)
                .setPositiveButton("Yes", (d, w) -> finish())
                .setNegativeButton("No", null)
                .setCancelable(true)
                .show());
        }
        @JavascriptInterface public void SetOnError(String cb) {}
    }
}
