# Claudable di Termux (Android ARM64) - Fix Prisma

Masalah: Prisma engine native (libquery_engine-debian-*.so.node) hanya ada
untuk x86_64. Android ARM64 tidak bisa menjalankannya (error EM_X86_64).
Solusi: engineType="client" (query compiler WASM) + @prisma/adapter-better-sqlite3.

Kombinasi ini sudah diuji penuh (CRUD, relasi, unique, cascade delete) di
Prisma 6.19.3 + better-sqlite3 12.

## Langkah (jalankan di folder Claudable)

1. Build tools untuk compile better-sqlite3 di Termux (sekali saja):
   pkg install python make clang sqlite -y

2. Pasang kombinasi versi yang terverifikasi:
   npm install prisma@6.19.3 @prisma/client@6.19.3 @prisma/adapter-better-sqlite3@6.19.3 better-sqlite3@12

3. Bersihkan cache dan regenerasi client:
   rm -rf node_modules/.prisma
   npx prisma generate

4. Salin file baru dari zip ini:
   - lib/db/client.ts  -> timpa file lama

5. Pastikan di .env:
   DATABASE_URL="file:./prisma/dev.db"

6. Buat database (sekali saja; hapus dulu prisma/dev.db lama kalau ada
   sisa percobaan yang kosong):
   [ -f prisma/dev.db ] && rm prisma/dev.db
   mkdir -p prisma
   sqlite3 prisma/dev.db < claudable-ddl.sql

   DDL ini dibuat oleh "prisma migrate diff" resmi, jadi strukturnya
   identik dengan hasil prisma db push. JANGAL jalankan
   prisma db push / prisma migrate di Termux (butuh engine native).

7. Jalanin:
   npm run dev

## Kalau npm install better-sqlite3 gagal compile
   npm rebuild better-sqlite3
   (kalau masih gagal, paste errornya)
