import { PrismaClient } from '@prisma/client';
import { PrismaBetterSQLite3 } from '@prisma/adapter-better-sqlite3';

// Prisma di Android/Termux (ARM64): engine native (libquery_engine-*.so.node)
// tidak tersedia untuk Android, jadi kita pakai jalur engine-free:
// query compiler WASM + driver adapter better-sqlite3.
// Syarat: prisma/schema.prisma memakai engineType = "client".

const url = process.env.DATABASE_URL ?? 'file:./prisma/dev.db';

const globalForPrisma = global as unknown as { prisma?: PrismaClient };

function createPrisma(): PrismaClient {
  const adapter = new PrismaBetterSQLite3({ url });
  return new PrismaClient({
    adapter,
    log:
      process.env.NODE_ENV === 'development'
        ? ['query', 'error', 'warn']
        : ['error'],
  });
}

export const prisma = globalForPrisma.prisma ?? createPrisma();

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prisma;
}
