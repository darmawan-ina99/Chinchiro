// ============================================================
//  ROLL ENGINE v7.0 — PORT SETIA dari The Dice 1.4 ASLI
//
//  Perubahan v7.0: SEMUA rumus dan ketentuan dihapus.
//   Hasil murni acak 1-6 per dadu, saling bebas (random alami).
//   Tanpa urutan berhenti; tanpa aturan tahan-layar.
//  (sumber: hasil dekompilasi APK asli, TheDiceActivity.java)
//
//  Mekanika asli yang dipulihkan:
//   1. KONTER GLOBAL (secCounter asli): semua dadu berputar
//      SEREMPAK — wajah berganti serentak 1..6 (Tick200mils asli).
//   2. HITUNG MUNDUR 3 DETIK (postDelayed 3000L asli): semua
//      dadu wajib berputar minimal 3 detik.
//   3. BERHENTI DI WAJAH HASIL (secCounter == randArr asli):
//      setelah mundur selesai, dadu berhenti tepat saat wajah
//      yang sedang berputar sama dengan hasilnya.
//   4. Wajah baru meluncur masuk dari kanan, wajah lama mengecil
//      keluar ke kiri (show_right / hide_left asli).
//   5. TRANSISI PEMBUKA TANPA JEDA (perbaikan v6.0): kode asli
//      (onClick) TIDAK PERNAH menahan wajah 6 diam sejenak sebelum
//      bergerak. Ia hard-cut isi lama (hasil roll sebelumnya)
//      menjadi wajah 6, lalu DALAM INSTAN YANG SAMA langsung
//      memulai animasi slide 6 -> 1 — satu gerakan menyambung,
//      bukan "diam lalu baru geser". Versi v5.9.2 kemarin menahan
//      wajah 6 diam dulu dengan setTimeout sebelum tick pertama,
//      sehingga terasa dua gerakan terpisah (patah/kasar). v6.0
//      memperbaiki ini: transisi pembuka 6->1 kini memakai
//      showFace() yang sama, dipicu LANGSUNG saat roll dimulai
//      (bukan menunggu timer), persis seperti kode asli.
//
//  Penyesuaian dari asli:
//   - Tempo 250ms per wajah = 4 wajah/detik (permintaan user);
//     tempo asli 200ms = 5 wajah/detik.
//   - Hasil dadu murni acak 1-6 per dadu, saling bebas (v7.0).
// ============================================================

var domBalls = [];
var balls = [];

// Tempo ganti wajah: ~4,4 wajah per detik = 225ms per frame
// (sedikit lebih cepat dari sebelumnya yang 250ms, atas permintaan user)
var FRAME_MS = 225;
// Hitung mundur asli: semua dadu wajib berputar minimal 3 detik
var MIN_SPIN_MS = 3000;

// Konter global wajah (0..5 = wajah 1..6), asli: secCounter
var secCounter = 0;
var minSpinDone = false;   // minimal 3 dtk sudah terpenuhi
var stopWindowOpen = false; // jendela stop terbuka (mulai dari wajah 2)

// Inisialisasi proses animasi (rolling)
function initRoll(elements) {
    domBalls = Array.prototype.slice.call(elements);
    balls = [];

    domBalls.forEach(function(element, index) {
        balls.push({
            element: element,
            id: index,
            value: Number(results[index]), // hasil dari Rule Engine (1-6)
            stoped: false // penamaan asli dipertahankan
        });
    });

    rolling = true;
    secCounter = 5;          // asli: secCounter = 5 saat dadu dilempar
    minSpinDone = false;
    stopWindowOpen = false;

    // Minimal 3 detik berputar (asli: postDelayed 3000L).
    setTimeout(function() {
        minSpinDone = true;
    }, MIN_SPIN_MS);

    // FRAME PEMBUKA (perilaku v5.9.1 yang sudah pas): wajah 6 meluncur
    // masuk menggantikan hasil lemparan sebelumnya, dadu diam sejenak,
    // lalu tick pertama menggesernya ke 1, 2, 3 dst.
    // PENGECUALIAN roll PERTAMA: saat game baru dibuka, dadu memang
    // sudah diam di wajah 6 statis. Animasi pembuka justru membuatnya
    // kasar (wajah statis terbuang seketika ladi dadu kosong sesaat).
    // Jadi jika sudah diam di 6, biarkan saja — tick pertama nanti
    // menggesernya mulus ke 1.
    balls.forEach(function(ball) {
        var $element = $(ball.element);
        var diamDi6 = $element.find("img.left[src='Img/6.svg']").length > 0;
        if (!diamDi6) {
            showFace(ball, 6);
        }
    });

    // Tick pertama (asli: postDelayed(tick, 200L))
    setTimeout(tick, FRAME_MS);
}

// Satu langkah putaran global: majukan wajah, perbarui semua dadu
// yang masih berputar (asli: Tick200mils.run)
function tick() {
    // Majukan konter global, kembali ke 0 setelah 5 (asli)
    secCounter += 1;
    if (secCounter >= 6) {
        secCounter = 0;
    }

    var face = secCounter + 1; // DICE_IMG[secCounter] = wajah secCounter+1
    var anySpinning = false;

    // (v7.0) BERHENTI ALAMI: begitu hitung mundur 3 detik selesai,
    // setiap dadu berhenti saat wajahnya sendiri muncul — persis
    // perilaku aplikasi asli. Tidak ada lagi urutan nilai dan
    // tidak ada syarat sentuhan. Angka kembar tetap berhenti
    // bersamaan karena wajahnya muncul di tick yang sama.
    if (!stopWindowOpen && minSpinDone) {
        stopWindowOpen = true;
    }

    balls.forEach(function(ball) {
        if (ball.stoped) {
            return;
        }

        // Tetap stop-on-face: dadu berhenti tepat saat wajah yang
        // berputar = hasilnya, sehingga mendarat alami tanpa snap
        if (stopWindowOpen && face == ball.value) {
            showFace(ball, face); // wajah hasil meluncur masuk...
            ball.stoped = true;   // ...lalu dadu diam
        } else {
            showFace(ball, face);
            anySpinning = true;
        }
    });

    if (anySpinning) {
        // Lanjut putaran global (asli: postDelayed(tick, 200L))
        setTimeout(tick, FRAME_MS);
    } else {
        // Tunggu wajah terakhir selesai meluncur masuk, lalu selesai
        setTimeout(onAllStoped, FRAME_MS);
    }
}

// Cek apakah semua dadu sudah berhenti
function isAllStoped() {
    for (var i in balls) {
        if (!balls[i].stoped) {
            return false;
        }
    }
    return true;
}

// Fungsi yang dieksekusi setelah semua animasi berhenti
function onAllStoped() {
    rolling = false;
    prevRes = results;
    preRes = [];
    round += 1;
    isRemoted = false;
}

// Tampilkan satu wajah pada satu dadu.
// PORT ANIMASI ASLI (show_right.xml + hide_left.xml dari APK asli):
//  - Wajah baru: pivotX 100% pivotY 50%, skala X 0 -> 1, skala Y 0.8 -> 1
//    (tumbuh dari sliver tipis di tepi kanan menjadi wajah penuh).
//  - Wajah lama: pivotX 0% pivotY 50%, skala X 1 -> 0, skala Y 1 -> 0.8
//    (menyusut menjadi sliver tipis lalu hilang di tepi kiri).
//  - Durasi sama dengan tempo tick (asli 200ms), interpolator
//    AccelerateDecelerate bawaan Android ~= cubic-bezier(0.42,0,0.58,1).
//  - Dijalankan lewat CSS transform (akselerasi GPU, tanpa layout ulang)
//    sehingga putarannya selicin aplikasi asli yang memakai ScaleAnimation.
function showFace(ball, face) {
    var $element = $(ball.element);
    var EASE = "cubic-bezier(0.42, 0, 0.58, 1)"; // ~= AccelerateDecelerateInterpolator

    // Wajah sebelumnya dipromosikan jadi wajah lama; dia masih terlihat
    // penuh dan akan menyusut keluar — transisi dua lapis versi asli.
    $element.find(".right").removeClass("right").addClass("left");

    // Wajah baru dipasang dalam keadaan sliver di tepi kanan
    // (asli: fromXScale=0, fromYScale=0.8, pivotX=100%)
    $element.append('<img class="right" src="Img/' + face + '.svg">');
    var $newFace = $element.find(".right");
    $newFace.css({
        "transform-origin": "100% 50%",
        "transform": "scale(0, 0.8)",
        "transition": "none"
    });

    // Paksa satu kali reflow agar kondisi awal terpasang dulu,
    // baru mulai transisi ke ukuran penuh (asli: toXScale=1, toYScale=1)
    $newFace.get(0).offsetWidth;
    $newFace.css({
        "transition": "transform " + FRAME_MS + "ms " + EASE,
        "transform": "scale(1, 1)"
    });

    // Semua wajah lama menyusut menjadi sliver di tepi kiri lalu dibuang
    // (asli: toXScale=0, toYScale=0.8, pivotX=0%, fillAfter=false)
    $element.find(".left").each(function() {
        var old = this;
        old.style["transform-origin"] = "0% 50%";
        old.style.transition = "transform " + FRAME_MS + "ms " + EASE;
        old.style.transform = "scale(0, 0.8)";
        setTimeout(function() {
            $(old).remove();
        }, FRAME_MS);
    });
}
