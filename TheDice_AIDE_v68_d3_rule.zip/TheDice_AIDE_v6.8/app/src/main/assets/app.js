// Android bridge for the original DroidScript HTML.
// Game files are copied from the original SPK without changing their logic.
