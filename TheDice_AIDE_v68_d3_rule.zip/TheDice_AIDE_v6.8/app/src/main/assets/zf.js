function select(q){
 return document.querySelector(q);
}

function selectAll(q){
 return document.querySelectorAll(q);
}

function elById(id){
 return document.getElementById(id);
}


function elAnim(el,anim){
    oldAnim=el.classList.item(el.classList.length-1);
    el.classList.remove(oldAnim);
    setTimeout(function(){
      el.classList.add("animate__animated","animate__"+anim);
    },200);
}

function showAndHide(page,animShow,animHide,time,text){
  if(text){
   elById(page).innerHTML= text;
  }
  showPage(page,animShow);
  setTimeout(hidePage,time,page,animHide);
}


function showPage(id,anim){
   window.scrollTo(0,0);
   var el=elById(id);
   if( el.style.display!="block"){
    el.style.display="block";
    zIndexPage+=1;
    el.style.zIndex=zIndexPage;
    oldAnim=el.classList.item(el.classList.length-1);
    el.classList.remove(oldAnim);
    el.classList.add("animate__animated","animate__"+(anim||"slideIn"));
    containerPage.push(id);
   }
}

function hidePage(id,anim){
    var el=elById(id);
    oldAnim=el.classList.item(el.classList.length-1);
    el.classList.remove(oldAnim);
    el.classList.add("animate__animated","animate__"+(anim||"rotateOutUpRight"));
    var index = containerPage.indexOf(id);
    if(index > -1) {
      containerPage.splice(index, 1);
      }
   
    setTimeout(function(){el.style.display="none";},600);
}

function defaultBack(){
if( loadBoolean("CanGoBack",true )){
  if(containerPage.length<2){
  // BUG FIX: dulu app.CreateYesNoDialog (tidak ada di bridge -> crash).
  // Sekarang dialog ditangani langsung oleh MainActivity.ShowYesNo.
  app.ShowYesNo("Tutup aplikasi ?");
  }
  else{
   hidePage(containerPage[containerPage.length-1]);
  }

}
else{
   showPopup("Tekan tanda silang 'x' untuk kembali" );
 }
 
}

function customBack(){
     $("#c-game").css({
                   left:"110%",
       })
     $("#splash img").get(0).style.animation="rotateZoomOut 0.4s  linear forwards";
     setTimeout( function(){
     app.Exit();
     },500);
}


function randBetween(min,max){
  return Math.floor(Math.random() * (max-min+1)) + min; 
}

/// preview image saat upload
function prevImg(event,img) {
  img.src = URL.createObjectURL(event.target.files[0]);
}

function showPopup(txt){
   app.ShowPopup( txt );
}
function showProgress(txt){
   showPage("ispinner","fadeIn");
}
function hideProgress(){
   hidePage("ispinner","fadeOut");
}
function saveText(key, val){
   app.SaveText(key,val );
}
function loadText(key,val){
   return app.LoadText(key,val );
}

function saveNumber(key, val){
   app.SaveNumber(key,val );
}
function loadNumber(key,val){
   return app.LoadNumber(key,val );
}

function saveBoolean(key,val){
   app.SaveBoolean(key,val );
}
function loadBoolean(key,val){
   return app.LoadBoolean(key,val );
}

function setOnError(cb){
   app.SetOnError(cb );
}
function setOptions(opt){
   app.SetOptions(opt );
}

function setOrientation(orient){
   app.SetOrientation(  orient )
}

function setScreenMode(mode){
   app.SetScreenMode(mode )
}