package com.thedice.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.content.SharedPreferences;
import android.widget.Toast;
import android.app.AlertDialog;

public class MainActivity extends Activity {
    private WebView webView;
    private SharedPreferences prefs;
    private boolean backEnabled = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        prefs = getSharedPreferences("TheDice", MODE_PRIVATE);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.setLayerType(WebView.LAYER_TYPE_HARDWARE, null);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setUseWideViewPort(false);
        s.setLoadWithOverviewMode(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new DroidScriptBridge(), "app");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/The Dice.html");
    }

    @Override public void onBackPressed() {
        // BUG FIX: tombol back dulu tidak berfungsi sama sekali karena
        // EnableBackKey(false) membuat method ini tidak melakukan apa pun.
        // Konvensi DroidScript: EnableBackKey(false) = tombol back ditangani
        // JavaScript lewat fungsi global OnBack.
        // Di dalam game  : OnBack = hideGame -> balik ke menu awal.
        // Di menu awal   : OnBack = exit     -> keluar aplikasi.
        if (backEnabled) { super.onBackPressed(); return; }
        webView.evaluateJavascript(
            "typeof OnBack === 'function' ? OnBack() : app.Exit()", null);
    }

    private class DroidScriptBridge {
        @JavascriptInterface public void SetScreenMode(String mode) {}
        @JavascriptInterface public void EnableBackKey(boolean enabled) { backEnabled = enabled; }
        @JavascriptInterface public void SetDebugEnabled(boolean enabled) {}
        @JavascriptInterface public void SetOrientation(String orientation) {}
        @JavascriptInterface public void SetOptions(String key, boolean value) {}
        @JavascriptInterface public void SetBackColor(String color) {}
        @JavascriptInterface public String GetAppPath() { return "/android_asset/The Dice"; }
        @JavascriptInterface public void CopyFile(String src, String dst) {}
        @JavascriptInterface public void Exit() { runOnUiThread(() -> finish()); }
        @JavascriptInterface public void PreventScreenLock(boolean yes) {
            runOnUiThread(() -> {
                if (yes) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }
        @JavascriptInterface public void SaveBoolean(String key, boolean value) { prefs.edit().putBoolean(key, value).apply(); }
        @JavascriptInterface public boolean LoadBoolean(String key, boolean def) { return prefs.getBoolean(key, def); }
        @JavascriptInterface public void SaveText(String key, String value) { prefs.edit().putString(key, value).apply(); }
        @JavascriptInterface public String LoadText(String key, String def) { return prefs.getString(key, def); }
        @JavascriptInterface public void SaveNumber(String key, double value) { prefs.edit().putLong(key, Double.doubleToRawLongBits(value)).apply(); }
        @JavascriptInterface public double LoadNumber(String key, double def) {
            long x = prefs.getLong(key, Double.doubleToRawLongBits(def));
            return Double.longBitsToDouble(x);
        }
        @JavascriptInterface public void ShowPopup(final String text) {
            // BUG FIX: dulu stub kosong, popup tidak pernah muncul
            runOnUiThread(() -> Toast.makeText(MainActivity.this, text, Toast.LENGTH_SHORT).show());
        }
        @JavascriptInterface public void ShowYesNo(final String title) {
            // BUG FIX: zf.js memanggil CreateYesNoDialog yang tidak ada di bridge (crash).
            // Sekarang dialog ya/tidak ditangani langsung di sisi Android.
            runOnUiThread(() -> new AlertDialog.Builder(MainActivity.this)
                .setMessage(title)
                .setPositiveButton("Yes", (d, w) -> finish())
                .setNegativeButton("No", null)
                .setCancelable(true)
                .show());
        }
        @JavascriptInterface public void SetOnError(String cb) {}
    }
}
